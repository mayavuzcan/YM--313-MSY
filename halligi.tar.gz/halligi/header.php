<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>HAL-LiGi</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>
  <div id="main">

	<div id="site_content">

	  <div id="header">

	    <div id="menubar">

		  <div id="welcome">
	        <h1><a href="#">Hal-LiGi</a></h1>
	      </div><!--close welcome-->

          <div id="menu_items">
	        <ul id="menu">
              <li class="current"><a href="index.php">Home</a></li>
              <li><a href="ourwork.php">Our Work</a></li>
              <li><a href="testimonials.php">Testimonials</a></li>
              <li><a href="projects.php">Projects</a></li>
              <li><a href="contact.php">Contact Us</a></li>
            </ul>
          </div><!--close menu-->

        </div><!--close menubar-->

	  </div><!--close header-->