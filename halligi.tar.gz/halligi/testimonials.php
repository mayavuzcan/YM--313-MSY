<?php
include "header.php";
include "sidebar.php";

?>


	   
      <div id="content">
        <div class="content_item">
          <h2>Testimonials</h2>
              <?php
              echo "Buraya Oyuncu Bilgileri Eklenecek";
              ?>

	    </div><!--close content_item-->
	  </div><!--content--> 
	  
	</div><!--close site_content--> 
 
  </div><!--close main-->


<?php

include "footer.php";

?>
