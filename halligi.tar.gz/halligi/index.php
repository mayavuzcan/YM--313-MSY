
		<?php
        include "header.php";

        include "sidebar.php";
        ?>


	 
	  <div id="content">
        
		<div class="content_item">
		  
		  <h1>Welcome To Your Website</h1> 
	      <p>This standards compliant, simple, fixed width website template is released as an 'open source' design (under the Creative Commons Attribution 3.0 Licence), which means that you are free to download and use it for anything you want (including modifying and amending it). If you wish to remove the &lsquo;ARaynorDesign&rsquo; link in the footer of the template, all I ask is for a donation of &pound;20.00 GBP.</p>	  
		  
		  <div class="content_images_text">
		  
		    <div class="content_image">
		      <img src="images/content_image.jpg" alt="content image" />
		    </div>
		  
		    <div class="image_text">
		      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin vehicula a nunc id euismod. Fusce enim ligula, facilisis nec gravida in, feugiat sit amet risus. Vivamus ornare leo convallis lorem posuere ullamcorper. Nunc convallis ultrices lacus sed faucibus. Vestibulum imperdiet non felis quis dapibus.</p>
		    </div>	

          </div>		  
		  
		  <div class="content_container">
		    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque cursus tempor enim. Aliquam facilisis neque non nunc posuere eget volutpat metus tincidunt.</p>
		  	<div class="button_small">
		      <a href="#">Read more</a>
		    </div><!--close button_small-->
		  </div><!--close content_container-->
          

		
		</div><!--close content_item-->
      
	  </div><!--close content--> 
	  
	</div><!--close site_content--> 
  
  </div><!--close main-->

        <?php

        include "footer.php";

        ?>

