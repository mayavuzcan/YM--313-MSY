<?php
include "header.php";
include "sidebar.php";

?>


	
      <div id="content">
        <div class="content_item">
          <h2>Latest Projects</h2>
            <div class="content_container">       
			  <h3>Example 1</h3>
			  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio.</p>
            </div><!--close content_container-->
            <div class="content_container">			  
			  <h3>Example 2</h3>
			  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio.</p>
			</div><!--close content_container-->
            <div class="content_container">       
			  <h3>Example 3</h3>
			  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio.</p>
            </div><!--close content_container-->
            <div class="content_container">			  
			  <h3>Example 4</h3>
			  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio.</p>
			</div><!--close content_container-->
	    </div><!--close content_item-->
      </div><!--close content-->
	  
	</div><!--close site_content--> 	
 
  </div><!--close main-->

  <?php

  include "footer.php";

  ?>

