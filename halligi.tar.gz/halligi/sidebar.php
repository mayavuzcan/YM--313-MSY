<div class="sidebar_container">

    <div class="sidebar">
        <div class="sidebar_item">
            <h2>New Website</h2>
            <p>Welcome to our new website. Please have a look around, any feedback is much appreciated.</p>
        </div><!--close sidebar_item-->
    </div><!--close sidebar-->

    <div class="sidebar">
        <div class="sidebar_item">
            <h2>Latest Update</h2>
            <h3>December 2013</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque cursus tempor enim.</p>
        </div><!--close sidebar_item-->
    </div><!--close sidebar-->

    <div class="sidebar">
        <div class="sidebar_item">
            <h3>November 2013</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque cursus tempor enim.</p>
        </div><!--close sidebar_item-->
    </div><!--close sidebar-->

</div><!--close sidebar_container-->